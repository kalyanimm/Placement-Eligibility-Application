#  Placement Eligibility App

A Streamlit-based web application to analyze student performance and determine their eligibility for placements. This app evaluates programming and soft skills using data stored in a SQLite database.

#  Features
- View All Students
- View Top students
- View Eligible students
- View the least problem-solving students
- View Each batch average score
- View all batches average score

